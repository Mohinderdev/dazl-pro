<?php
//
//use App\Modules\Payment\Models\Payment;
//use Illuminate\Database\Seeder;
//
//class PaymentSeeder extends Seeder
//{
//    /**
//     * Run the database seeds.
//     *
//     * @return void
//     */
//    public function run()
//    {
//        Payment::firstOrCreate([
//            'id' => 1,
//            'name' => json_encode([
//                'ar' => 'موقف',
//                'en' => 'Parking',
//            ])
//        ]);
//
//        Payment::firstOrCreate([
//            'id' => 2,
//            'name' => json_encode([
//                'ar' => 'حديقة',
//                'en' => 'Garden',
//            ])
//        ]);
//
//    }
//}
