<style>
    div#items .row {
        display: flex;
        flex-wrap: wrap;
        width: 100%;
    }
</style>

<div class="kt-portlet__body">
    @component('admin.fields.text', ['multiLang' => false, 'label' => 'Name', 'path' => 'feature-options', 'name' => 'name', 'value' => @$row]) @endcomponent
    @component('admin.fields.select' , ['name' => 'feature_id' ,'label' => 'Features' , 'list' => $features ,'display_column' => 'name' , 'defaultVal' => 'Features' ,'selected' => @$row->feature_id]) @endcomponent
        <div id="items" class="form-group">
            @if(isset($row))

                @forelse($row['featureissues'] as $fetures)
                    <div class="row">
                        <div class="col-md-6 margin-bottom">
                            <label class="control-label" for="textinput" style="text-align: left">Issues</label>
                    <input id="textinput" name="textinput[]" type="text" placeholder="Enter Issue" value="{{$fetures->name}}" class="form-control input-md"><br/>
                        </div>
                    <div class="col-md-6 form-group">
                        <label for="feature_id"> Service Type</label>
                        <select name="service_type_id[]" id="single" class="form-control">
                            @foreach($serviceTypes as $serv)
                                @if($serv->id == $fetures->service_type_id)
                                    <option value="{{$serv->id}}" selected>{{$serv->name}}</option>
                                @else
                                    <option value="{{$serv->id}}">{{$serv->name}}</option>
                                @endif

                            @endforeach
                        </select>
                        <small class="text-danger"></small>
                    </div>
                    </div>
                    @endforeach
                    @endif
                    <div class="row" style="padding-bottom: 34px;">
                        <div class="col-md-4 margin-bottom">
                            <label class="control-label" for="textinput" style="text-align: left">Need Dazl Score</label>

                            <input type="number" placeholder="Enter Score" name="need_dazl" class="form-control input-md">

                        </div><div class="col-md-4 margin-bottom">
                            <label class="control-label" for="textinput" style="text-align: left">Market Ready Score</label>

                            <input type="number" placeholder="Enter Score" name="market_dazl" class="form-control input-md">

                        </div>
                        <div class="col-md-4 margin-bottom">
                            <label class="control-label" for="textinput" style="text-align: left">Dazzling Score</label>

                            <input type="number" placeholder="Enter Score" name="dazzling" class="form-control input-md">

                        </div>
                    </div>

            <div class="row">
            <div class="col-md-6 margin-bottom">
                <label class="control-label" for="textinput" style="text-align: left">New Issues</label>

                <input id="textinput" name="textinput[]" type="text" placeholder="Enter Issue" class="form-control input-md">

            </div>

                            <div class="col-md-6 form-group">
                                <label for="feature_id"> Service Type</label>
                                <select name="service_type_id[]" id="single" class="form-control">
                                    @foreach($serviceTypes as $serv)
                                        <option value="{{$serv->id}}">{{$serv->name}}</option>
                                    @endforeach
                                </select>
                                <small class="text-danger"></small>
                            </div>

            </div>

        </div>

        <button id="add" class="btn add-more button-yellow uppercase" type="button">+ Add another Issues</button> <button class="delete btn button-white uppercase" type="button">- Remove referral</button>

</div>

<div class="kt-portlet__foot">
    <div class="kt-form__actions">
        <div class="row">
            <div class="col-lg-6">
                <button type="submit" class="btn btn-primary submit_button"> {{ $submitButton }} </button>
                <button type="reset" class="btn btn-secondary"> Cancel </button>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        $(".delete").hide();
        //when the Add Field button is clicked
        $("#add").click(function(e) {
            $(".delete").fadeIn("1500");
            //Append a new row of code to the "#items" div
            $("#items").append(
                '<div class="row next-referral"><div class="col-md-6 margin-bottom"><input id="textinput" name="textinput[]" type="text" placeholder="Enter Another Issue" class="form-control input-md"> </div>  <div class="col-md-6 form-group"> <select name="service_type_id[]" id="single" class="form-control">@foreach($serviceTypes as $serv)<option value="{{$serv->id}}">{{$serv->name}}</option>@endforeach</select> <small class="text-danger"></small> </div></div></div>'
            );
        });
        $("body").on("click", ".delete", function(e) {
            $(".next-referral").last().remove();
        });
    });

</script>
