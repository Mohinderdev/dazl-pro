<?php

namespace App\Modules\Blog\Features\Admin;

use App\Core\Feature;
use Illuminate\Http\Request;
use App\Core\Response\Admin\RespondWithRoute;
use App\Modules\Blog\Models\Blog;
use App\Modules\Blog\Requests\Admin\CreateBlogRequest;

class StoreBlogFeature extends Feature
{

    private $model;
    /**
     * StoreBlogFeature constructor.
     */
    public function __construct()
    {
        $this->model = new Blog;
    }

    /**
     *
     * @param Request $request
     * @return RespondWithView
     */
    public function handle(CreateBlogRequest $request)
    {
        $this->model->create($request->all());

        return $this->run(RespondWithRoute::class, [
            'route' => 'blogs.index',
            'message_type' => 'success',
            'message' => 'Added Successfully',
        ]);
    }

}
