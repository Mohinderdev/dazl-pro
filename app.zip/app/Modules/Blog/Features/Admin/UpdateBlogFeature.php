<?php

namespace App\Modules\Blog\Features\Admin;

use App\Core\Feature;
use Illuminate\Http\Request;
use App\Core\Response\Admin\RespondWithRoute;
use App\Modules\Blog\Models\Blog;
use App\Modules\Blog\Requests\Admin\UpdateBlogRequest;

class UpdateBlogFeature extends Feature
{

    private $model;
    /**
     * EditBlogFeature constructor.
     */
    public function __construct(Blog $Blog)
    {
        $this->model = $Blog;
    }

    /**
     *
     * @param Request $request
     * @return use App\Core\Response\Api\RespondWithRoute;
     */
    public function handle(UpdateBlogRequest $request)
    {
        $this->model->update($request->all());

        return $this->run(RespondWithRoute::class, [
            'route' => 'blogs.index',
            'message_type' => 'success',
            'message' => 'Updated Successfully',
        ]);
    }

}
