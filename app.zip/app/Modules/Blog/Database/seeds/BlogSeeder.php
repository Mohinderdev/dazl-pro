<?php
//
//use App\Modules\Blog\Models\Blog;
//use Illuminate\Database\Seeder;
//
//class BlogSeeder extends Seeder
//{
//    /**
//     * Run the database seeds.
//     *
//     * @return void
//     */
//    public function run()
//    {
//        Blog::firstOrCreate([
//            'id' => 1,
//            'name' => json_encode([
//                'ar' => 'موقف',
//                'en' => 'Parking',
//            ])
//        ]);
//
//        Blog::firstOrCreate([
//            'id' => 2,
//            'name' => json_encode([
//                'ar' => 'حديقة',
//                'en' => 'Garden',
//            ])
//        ]);
//
//    }
//}
