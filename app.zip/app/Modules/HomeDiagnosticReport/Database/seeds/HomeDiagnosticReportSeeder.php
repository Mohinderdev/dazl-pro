<?php
//
//use App\Modules\HomeDiagnosticReport\Models\HomeDiagnosticReport;
//use Illuminate\Database\Seeder;
//
//class HomeDiagnosticReportSeeder extends Seeder
//{
//    /**
//     * Run the database seeds.
//     *
//     * @return void
//     */
//    public function run()
//    {
//        HomeDiagnosticReport::firstOrCreate([
//            'id' => 1,
//            'name' => json_encode([
//                'ar' => 'موقف',
//                'en' => 'Parking',
//            ])
//        ]);
//
//        HomeDiagnosticReport::firstOrCreate([
//            'id' => 2,
//            'name' => json_encode([
//                'ar' => 'حديقة',
//                'en' => 'Garden',
//            ])
//        ]);
//
//    }
//}
