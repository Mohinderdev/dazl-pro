<?php
namespace App\Modules\HomeDiagnosticReport\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Modules\HomeDiagnosticReport\Requests\Api\CreateHomeDiagnosticReportRequest;
use App\Modules\HomeDiagnosticReport\Requests\Api\GetHouseDataRequest;
use App\Modules\HomeDiagnosticReport\Services\HomeDiagnosticReportService;

class HomeDiagnosticReportController extends Controller
{
    private HomeDiagnosticReportService $homeDiagnosticReportService;

    public function __construct(HomeDiagnosticReportService $homeDiagnosticReportService)
    {
        $this->homeDiagnosticReportService = $homeDiagnosticReportService;
    }

    public function store(CreateHomeDiagnosticReportRequest $createHomeDiagnosticReportRequest){

        $homeD = $this->homeDiagnosticReportService->storeHomeDiagnosticReport($createHomeDiagnosticReportRequest->all());
        return response()->json($homeD);
    }

    public function getHouseData(GetHouseDataRequest $getHouseDataRequest): \Illuminate\Http\JsonResponse
    {


        $houseData = $this->homeDiagnosticReportService->getHouseData(
            $houseData =$getHouseDataRequest->address
        );


        $property = @$houseData->property[0];
        $type = @$property->summary->propType ? $property->summary->propType : $houseData->type;
        $yr_built = @$property->summary->yearBuilt ? $property->summary->yearBuilt : $houseData->year_built;
        $basement_type = @$property->building->interior->bsmtType? $property->summary->yearBuilt : $houseData->basement;
        $grossSize = @$property->building->size->grossSize  ? $property->building->size->grossSize : $houseData->gross_size;
        $bathrooms = @$property->building->rooms->bathsTotal ? @$property->building->rooms->bathsTotal : $houseData->bathrooms;
        $bedrooms = @$property->building->rooms->beds ? @$property->building->rooms->beds : $houseData->bedrooms;
        $spaces = @$property->building->summary->unitsCount ? @$property->building->summary->unitsCount : $houseData->spaces;
        $parkingFeatures = @$property->building->summary->unitsCount? @$property->building->summary->unitsCount :$houseData->parking_features;
        $propertyStories = @$property->building->summary->levels ? @$property->building->summary->levels : $houseData->property_stories;
        $structureType = @$property->summary->propSubType ? @$property->summary->propSubType : $houseData->structure_type;
        $lotSize = @$property->lot->lotSize2 ? @$property->lot->lotSize2 : $houseData->lot_size;
        $location = @$property->address->locality ? @$property->address->locality : $houseData->location;
        $foundationType = @$property->building->construction->foundationType ? @$property->building->construction->foundationType : $houseData->foundation_type;
        $taxAccessedValue = @$property->assessment->market->mktTtlValue ? @$property->assessment->market->mktTtlValue : $houseData->tax_accessed_value;
        $annualTaxAmount = @$property->assessment->tax->taxAmt  ? @$property->assessment->tax->taxAmt  : $houseData->annual_tax_amount;
        $saleDate = @$property->sale->saleTransDate  ? @$property->sale->saleTransDate  : $houseData->sale_date;
        $saleAmount = @$property->sale->saleAmountData->saleAmt ? @$property->sale->saleAmountData->saleAmt  : $houseData->sale_amount;
        return response()->json([
            "type" => $type,
            "year_built" => $yr_built,
            "basement" => $basement_type,
            "gross_size" => $grossSize,
            "bedrooms" => $bedrooms,
            "bathrooms" =>$bathrooms,
            "spaces" => $spaces,
            "parking_features" => $parkingFeatures,
            "property_stories" => $propertyStories,
            "structure_type" => $structureType,
            "lot_size" => $lotSize,
            "location" => $location,
            "foundation_type" => $foundationType,
            "tax_accessed_value" => $taxAccessedValue,
            "annual_tax_amount" => $annualTaxAmount,
            "sale_date" => $saleDate,
            "sale_amount" => $saleAmount,

        ]);
    }

    public function getPHDForRealtor(): \Illuminate\Http\JsonResponse
    {
        $reports = $this->homeDiagnosticReportService->getPHDUsingRealtorId();
        return response()->json([
           'reports' => $reports
        ]);
    }

}
