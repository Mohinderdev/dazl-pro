<?php

namespace App\Modules\HomeDiagnosticReport\Repositories;


use App\Core\Repositories\BaseRepository;
use App\Modules\HomeDiagnosticReport\Models\HomeDiagnosticReport;
use App\Modules\HomeDiagnosticReport\Models\HomeDiagnosticReportFeatureOption;

class HomeDiagnosticReportRepo extends BaseRepository
{
    protected HomeDiagnosticReport $homeDiagnosticReport;
    protected HomeDiagnosticReportFeatureOption $homeDiagnosticReportFeatureOption;
    public function __construct(HomeDiagnosticReport $homeDiagnosticReport , HomeDiagnosticReportFeatureOption $homeDiagnosticReportFeatureOption)
    {
        $this->homeDiagnosticReportFeatureOption = $homeDiagnosticReportFeatureOption;
        $this->homeDiagnosticReport = $homeDiagnosticReport;
        parent::__construct($homeDiagnosticReport);
    }

    public function store(array $data){
        // Todo : Store
    }

    public function insertIntoProjectFeatureOptionTable(array $data){

        return $this->homeDiagnosticReportFeatureOption->insert($data);
    }

    public function getHDRFromRealtorId(int $realtorId){
        return $this->homeDiagnosticReport->with('house')
            ->whereHas('house' , function ($q) use ($realtorId) {
                return $q->where('realtor_id' , $realtorId);
            })->get();
    }

}
