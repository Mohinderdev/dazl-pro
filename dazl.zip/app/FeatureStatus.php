<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FeatureStatus extends Model
{
    //
}
