<?php


namespace App\Modules\HomeDiagnosticReport\Services;

use App\Exceptions\HouseDataNotFound;
use App\Jobs\SendMAIL;
use App\Mail\SendEmail;
use App\Modules\Customer\Repositories\CustomerApiRepo;
use App\Modules\Feature\Models\Feature;
use App\Modules\Feature\Repositories\FeatureApiRepo;
use App\Modules\FeatureIssue\Models\FeatureIssue;
use App\Modules\FeatureOption\Models\FeatureOption;
use App\Modules\HomeDiagnosticReport\Models\HomeDiagnosticReport;
use App\Modules\HomeDiagnosticReport\Repositories\HomeDiagnosticReportRepo;
use App\Modules\House\Repositories\HouseRepo;
use App\Modules\Project\Repositories\ProjectApiRepo;
use App\ThirdParties\AttomData\AttomData;
use App\ThirdParties\UploadImages\ImagesFactoryInterface;
use Carbon\Carbon;
use GuzzleHttp\Exception\BadResponseException;
use Illuminate\Database\Eloquent\Collection;
use \stdClass;
use DB;

class HomeDiagnosticReportService
{
    protected HomeDiagnosticReportRepo $homeDiagnosticReportRepo;
    protected HouseRepo $houseRepo;
    protected ImagesFactoryInterface $imagesFactory;
    private CustomerApiRepo $customerApiRepo;
    private AttomData $attomData;
    private ProjectApiRepo $projectApiRepo;
    private FeatureApiRepo $featureApiRepo;

    public function __construct(
        HomeDiagnosticReportRepo $homeDiagnosticReportRepo,
        ImagesFactoryInterface $imagesFactory,
        HouseRepo $houseRepo ,
        CustomerApiRepo $customerApiRepo,
        AttomData $attomData,
        ProjectApiRepo $projectApiRepo,
        FeatureApiRepo $featureApiRepo
    )
    {
        $this->houseRepo = $houseRepo;
        $this->homeDiagnosticReportRepo = $homeDiagnosticReportRepo;
        $this->imagesFactory = $imagesFactory;
        $this->customerApiRepo = $customerApiRepo;
        $this->attomData = $attomData;
        $this->projectApiRepo = $projectApiRepo;
        $this->featureApiRepo = $featureApiRepo;
    }

    public function storeHomeDiagnosticReport(array $request){
     if($request['house_id'] == "" && $request['customer_id'] == "" ) {
         $addressse = explode(' ', $request['address']);
         $zip = array_pop($addressse);

         $addressOne = $addressse[0];
         $addressTwo = $addressse[1];
         $realtorId = auth('realtor')->id();
         $realtor = auth('realtor')->user();
         $clientBarePassword = rand(10000, 100000);
         $clientPassword = bcrypt($clientBarePassword);
         $customerData = [
             "first_name" => $request['first_name'],
             "last_name" => $request['last_name'],
             "phone_number" => '',
             "zip_code" => $zip,
             "email" => $request['client_email'],
             "password" => $clientPassword,
         ];

         $customer = $this->findOrCreateCustomer($request['client_email'], $customerData);
         $customerWasRecentlyCreated = $customer->wasRecentlyCreated;


         if ($customerWasRecentlyCreated) {
             $this->sendEmailToCustomer(
                 $customer->email,
                 $clientBarePassword,
                 "{$realtor->first_name} {$realtor->last_name}",
                 "{$customer->first_name} {$customer->last_name}"
             );
         }

         $house = $this->createHouse($request, $realtorId, $customer->id);
         $roomIds = array_keys($request['rooms']);
         $house->rooms()->attach($roomIds);
     }
     else{
         $house = new stdClass();
         $house->id= $request['house_id'];
         $customer = new stdClass();
         $customer->id= $request['customer_id'];

     }
        $homeDiagnosticReport = $this->homeDiagnosticReportRepo->create([
            'house_id' => $house->id,
            'highest_price' => $request['highest_price'],
            'lowest_price' => $request['lowest_price'],
            'score' => $request['score'],
            'description' => $request['phd_description']
        ]);

        if(@$request['images']){
            $data = $this->uploadImagesAndSetImageDescriptionArray($request['images']);

            $homeDiagnosticReport->images()->createMany($data);
        }

//        $pdf_url = $this->imagesFactory->uploadImage($request['pdf_file']);
        $pdf_url ='test';
        $homeDiagnosticReport->images()->create(['url'  => $pdf_url]);
        $featuresIds = $this->getFeatureForIssuesAndOptions($request['rooms']);
        foreach ($request['rooms'] as $roomId => $room) {
            $features = array_keys($room['feature_options']);


            if (@$room['feature_issues']){
                $projectMetaData = [
                    'customer_id' => $customer->id,
                    'room_id' => $roomId,
                    'start_date' => Carbon::now()->format('Y-m-d'),
                    'home_diagnostic_report_id' => $homeDiagnosticReport->id,
                    'feature_issue_id'=>1,
                    'status'=>1,
                    'feature_description'=>'test',
                ];

                $project = $this->projectApiRepo->createProject($projectMetaData);

                $project->features()->attach($featuresIds['features_for_issues']);

                $featureIssuesData = $this->prepareFeatureIssuesData($project->features ,$room['feature_issues'],$request['feature_issues_images_descr'],$request['feature_status'],$request['feature_issues_images']);

                $this->projectApiRepo->insertIntoProjectFeatureIssueTable($featureIssuesData);

            }
            $homeDiagnosticReport->features()->attach($featuresIds['features_for_options']);
            $features = $homeDiagnosticReport->features;

            $featureIssuesData = $this->prepareFeatureOptionsData($features ,$room['feature_options']);

            $this->homeDiagnosticReportRepo->insertIntoProjectFeatureOptionTable($featureIssuesData);

        }
        $homeDiagnosticReport->customer = $customer->id;



        return $homeDiagnosticReport;
    }

    private function getFeatureForIssuesAndOptions($rooms): array{
        $featuresForOptions = [];
        $featuresForIssues = [];
        foreach ($rooms as $room){
            $featuresForOptions = array_merge($featuresForOptions ,array_keys($room['feature_options'] ?? []));
            $featuresForIssues = array_merge($featuresForIssues ,array_keys($room['feature_issues'] ?? []));
        }
        return [
            'features_for_options' => $featuresForOptions,
            'features_for_issues' => $featuresForIssues
        ];
    }

    private function uploadImagesAndSetImageDescriptionArray($images): array
    {

        $array = [];
        foreach ($images as $image){
            $url = $this->imagesFactory->uploadImage($image[0]);
            $array[] = [
                'url' => $url,
                'description' => $image[1]
            ];
        }
        return $array;
    }

    private function createHouse(array $data ,int $realtorID ,int $customerID){

        return $this->houseRepo->create([
            'name' => 'name',
            'year_built' => $data['year_built'],
            'realtor_id' => $realtorID,
            'customer_id' => $customerID,
            'bathrooms' => $data['bathrooms'],
            'bedrooms' => $data['bedrooms'],
            'basement' => $data['basement'],
            'gross_size' => $data['gross_size'],
            'spaces' => $data['spaces'],
            'parking_features' => $data['parking_features'],
            'property_stories' => $data['property_stories'],
            'structure_type' => $data['structure_type'],
            'lot_size' => $data['lot_size'],
            'location' => $data['location'],
            'foundation_type' => $data['foundation_type'],
            'tax_accessed_value' => $data['tax_accessed_value'],
            'annual_tax_amount' => $data['annual_tax_amount'],
            'sale_date' => $data['sale_date'],
            'sale_amount' => $data['sale_amount'],
            "type" => $data['type'],
            "address" => $data['address']

        ]);
    }

    private function findOrCreateCustomer(string $email ,array $customerData){
        return $this->customerApiRepo->findOrCreateCustomerByEmail($email ,$customerData);
    }

    private function sendEmailToCustomer(
        string $emailAddress,
        string $password,
        string $realtorName ,
        string $customerName
    ){
        $emailData = [
            'customer_name' => $customerName,
            'realtor_name' => $realtorName,
            'password' => $password,
            'email' => $emailAddress,
        ];
        $emailView = 'emails.customer_email';
        $emailSubject = 'A House has been created for you ,By a realtor ,Dazl !';
        $emailInstance = new SendEmail(
            $emailData,
            $emailView,
            $emailSubject
        );
        SendMAIL::dispatch([$emailAddress] ,$emailInstance);
    }

    public function getHouseData(
        string $address

    )
    {


        $addressse = explode(',', $address, '2');
        $addressOne = $addressse[0];
        $addressTwo = $addressse[1];
//        $addressOne = "$streetNumber $streetName";
//        $addressTwo = "$city $state $zipCode";
        if (DB::table('houses')->where('address', 'LIKE', '%' . $address . '%')
            ->exists()) {
            $response = DB::table('houses')->where('address', 'LIKE', '%' . $address . '%')
                ->first();
            return $response;
        } else {
            try {
                $response = $this->attomData->getAddress($addressOne, $addressTwo)->getBody()->getContents();
                return json_decode($response);
            } catch (BadResponseException $exception) {
                throw new HouseDataNotFound();
            }
        }
    }
    private function prepareFeatureIssuesData(Collection $features ,array $featureIssueIds,$desc,$status,$images):array{
//
        $array = [];
        $featureIssues = FeatureIssue::whereIn('id' , $featureIssueIds)
            ->with('feature')
            ->get();

        foreach ($featureIssues as  $key => $featureIssue){

            $featureProjectId  = $features->where('id' , $featureIssue->feature->id)->first()->pivot->id;
            $imagesurl=$this->imagesFactory->uploadImage($images[$key]);
            $array[] = [
                'feature_project_id' =>$featureProjectId,
                'feature_issue_id' => $featureIssue->id,
                'description' =>'test',
                'feature_description'=>$desc[$key],
                'status'=>$status[$key],
                'images'=>$imagesurl

            ];
        }

        return $array;
    }

    private function prepareFeatureOptionsData($features ,array $featureOptionId):array{

        $array = [];
        $featureOptions = FeatureOption::whereIn('id' , $featureOptionId)
            ->with('feature')
            ->get();
        foreach ($featureOptions as  $featureOption){

            $featureHomeDiagnosticReportId  = $features->where('id' , $featureOption->feature->id)->first()->pivot->id;

            $array[] = [
                'feature_home_diagnostic_report_id' =>$featureHomeDiagnosticReportId,
                'feature_option_id' => $featureOption->id
            ];
        }
        return $array;
    }

    public function getPHDUsingRealtorId(){
        $realtorId = auth('realtor')->id();
        return $this->homeDiagnosticReportRepo->getHDRFromRealtorId($realtorId);
    }
}
