<?php

namespace App\Modules\Company\Features\Admin;

use App\Core\Feature;
use Illuminate\Http\Request;
use App\Core\Response\Admin\RespondWithRoute;
use App\Modules\Company\Models\Company;
use App\Modules\Company\Requests\Admin\UpdateCompanyRequest;

class UpdateCompanyFeature extends Feature
{

    private $model;
    /**
     * EditCompanyFeature constructor.
     */
    public function __construct(Company $Company)
    {
        $this->model = $Company;
    }

    /**
     *
     * @param Request $request
     * @return use App\Core\Response\Api\RespondWithRoute;
     */
    public function handle(UpdateCompanyRequest $request)
    {
        $this->model->update($request->all());

        return $this->run(RespondWithRoute::class, [
            'route' => 'companies.index',
            'message_type' => 'success',
            'message' => 'Updated Successfully',
        ]);
    }

}
