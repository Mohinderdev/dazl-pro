<?php
namespace App\Modules\Company\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Modules\Company\Requests\Api\GetCompanyFromProfessionalRequest;
use App\Modules\Company\Services\CompanyService;
use Illuminate\Http\Request;


class CompanyController extends Controller
{
    protected CompanyService $companyService;

    public function __construct(CompanyService $companyService)
    {
        $this->companyService = $companyService;
    }

    public function getCompanyFromPro(GetCompanyFromProfessionalRequest $companyFromProfessionalRequest)
    {
        $company = $this->companyService->getCompanyFromPro($companyFromProfessionalRequest->professional_id);
        return  response()->json(($company)?[
            "name" => $company->company->name,
            "phone" => $company->company->phone,
            "email" => $company->company->email,
            "website" => $company->company->website,
            "address" => $company->company->address,
            "references" => $company->company->references,
            "description" => $company->company->description,
            "business_licence" => $company->company->business_licence,
            "project_portfolio" => $company->company->project_portfolio,
            "years_in_business" => $company->company->years_in_business,
            "insurance_certificate" => $company->company->insurance_certificate,
        ] : []);
    }

    public function update(Request $request){
        $this->companyService->updateCompany($request->all());
    }

}
