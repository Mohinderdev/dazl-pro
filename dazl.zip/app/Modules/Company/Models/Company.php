<?php

namespace App\Modules\Company\Models;

use Illuminate\Database\Eloquent\Model;

class Company extends Model
{

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'phone',
        'email',
        'website',
        'address',
        'references',
        'description',
        'business_licence',
        'project_portfolio',
        'years_in_business',
        'insurance_certificate',
    ];

    // relations

}
