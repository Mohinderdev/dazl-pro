<?php
//
//use App\Modules\BaseModule\Models\BaseModule;
//use Illuminate\Database\Seeder;
//
//class BaseModuleSeeder extends Seeder
//{
//    /**
//     * Run the database seeds.
//     *
//     * @return void
//     */
//    public function run()
//    {
//        BaseModule::firstOrCreate([
//            'id' => 1,
//            'name' => json_encode([
//                'ar' => 'موقف',
//                'en' => 'Parking',
//            ])
//        ]);
//
//        BaseModule::firstOrCreate([
//            'id' => 2,
//            'name' => json_encode([
//                'ar' => 'حديقة',
//                'en' => 'Garden',
//            ])
//        ]);
//
//    }
//}
