<?php
namespace App\Modules\Customer\Controllers\Api;

use App\Modules\Professional\Transformers\Api\ProfessionalResource;
use Illuminate\Http\Response;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Modules\Customer\Services\CustomerService;
use App\Modules\Customer\Models\Customer;
use App\Modules\Customer\Transformers\Api\CustomerResource;
use App\Modules\Customer\Requests\Api\LoginCustomerRequest;
use App\Modules\Customer\Requests\Api\RegisterCustomerRequest;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Validator;

/**
 * @group  Customers
 *
 * APIs for managing customers
 */
class CustomerController extends Controller
{
    private CustomerService $customerService;

    public function __construct(CustomerService $customerService)
    {
        $this->customerService = $customerService;
    }
    /**
     * Register Customer.
     * @bodyParam email string required polagorge@gmail.com
     * @bodyParam password string required 123123
     * @bodyParam first_name string required Paula
     * @bodyParam last_name string required George
     * @bodyParam phone_number string required +201272575873
     * @bodyParam zip_code string required 524587
     */
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'email' => ['required','unique:customers'],
            'password' => ['required','same:confirm_password','min:8','max:16'], //need to add more rules
            'confirm_password' => ['required'],
            'first_name' => ['required'],
            'last_name' => ['required'],
            'phone_number' => ['required'],
            'zip_code' => ['required'],
            'check_box' =>['required','accepted'],
        ]);

        //Send failed response if request is not valid
        if ($validator->fails()) {
            $message = [
                'message' => $validator->errors()->first()
            ];
            return response()->json($message,500);
        }
        $user = $this->customerService->registerClient($request);
        return new CustomerResource($user);
    }


    /**
     * Login Customer.
     * @bodyParam email string required polagorge@gmail.com
     * @bodyParam password string required 123123
     */
    public function login(LoginCustomerRequest $customerRequest): \Illuminate\Http\JsonResponse{
        $user = $this->customerService->loginClient($customerRequest);
    return ($user)? response()->json(['data' =>new CustomerResource($customerRequest) ])
            :
            response()->json([
                'message' => 'Please check your credentials'
            ],Response::HTTP_UNAUTHORIZED);

    }
    public function forgot(Request $request){

        $credentials = request()->validate(['email' => 'required|email']);
        $user = Customer::where('email', $request->email)->first();
        if (isset($user)) {

            $status = Password::sendResetLink($credentials);
            $status === Password::RESET_LINK_SENT;


            return response()->json([
                'status'=>$status,
                "message" => 'Reset password link sent on your email address.'
            ]);
        }
        else{
            return response()->json([
                'status'=>false,
                "message" => 'Email Id is not Exist '
            ]);
        }
    }
    /**
     * Logout Customer.
     *
     */
    public function logout(): \Illuminate\Http\JsonResponse
    {
        auth('customer')->logout();
        return response()->json([
            'message' => 'Customer is logged out'
        ],Response::HTTP_ACCEPTED);
    }

}
