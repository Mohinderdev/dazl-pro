<?php
namespace App\Enums;

final class ProjectStatusEnum{

    use EnumTrait;

    const PUBLISH = 'PUBLISH';
    const NOT_PUBLISHED = 'NOT_PUBLISHED' ;

}
