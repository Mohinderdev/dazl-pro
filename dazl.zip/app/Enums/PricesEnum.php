<?php
namespace App\Enums;

final class PricesEnum{

    use EnumTrait;

    const PROFESSIONAL = 4000;
    const REALTOR = 1000 ;

}
